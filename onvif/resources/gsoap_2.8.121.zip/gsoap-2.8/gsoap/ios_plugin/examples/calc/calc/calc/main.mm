//
//  main.m
//

#import <UIKit/UIKit.h>
#include "AppDelegate.h"
#include "../../calc.nsmap"


int main(int argc, char * argv[])
{
    @autoreleasepool
    {
        int retVal = UIApplicationMain(argc, argv, nil, @"AppDelegate");
        return retVal;
    }
}
