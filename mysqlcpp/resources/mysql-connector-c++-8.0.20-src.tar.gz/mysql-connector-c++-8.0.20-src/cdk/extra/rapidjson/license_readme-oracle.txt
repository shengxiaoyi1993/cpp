Further information regarding RapidJSON files included with
this Oracle package:

The license file for rapidjson states the following:
 "To avoid the problematic JSON license in your own projects,
  it's sufficient to exclude the bin/jsonchecker/ directory,
  as it's the only code under the JSON license."

We have removed the bin/jsonchecker/ directory, and we have
thus no code under the JSON license included.
